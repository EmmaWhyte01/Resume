$(document).ready(function(){
    $('.wall1').on('click',function(e){
        e.preventDefault();
        $('body').css('background','url("/images/man (1).jpg")');
    });
    $('.wall2').on('click',function(e){
        e.preventDefault();
        $('body').css('background','url("/images/man (2).jpg")');
    });
    $('.wall3').on('click',function(e){
        e.preventDefault();
        $('body').css('background','url("/images/man (3).jpg")');
    });
    $('.wall4').on('click',function(e){
        e.preventDefault();
        $('body').css('background','url("/images/man (4).jpg")');
    });
    $('.wall5').on('click',function(e){
        e.preventDefault();
        $('body').css('background','url("/images/man (5).jpg")');
    });
    $('.wall6').on('click',function(e){
        e.preventDefault();
        $('body').css('background','url("/images/man (6).jpg")');
    });
    $('.wall7').on('click',function(e){
        e.preventDefault();
        $('body').css('background','url("/images/man (7).jpg")');
    });
    $('.wall8').on('click',function(e){
        e.preventDefault();
        $('body').css('background','url("/images/man (8).jpg")');
    });
});