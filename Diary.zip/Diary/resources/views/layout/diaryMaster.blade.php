<!DOCTYPE html>
<html lang="en">
    <head>
        <title>@yield('title')</title>
        @section('meta-data')
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1">
        @show
        @section('core-css')
            <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
            <link href="/css/bootstrap.css" type="text/css" rel="stylesheet"/>
            <link href="/css/todostyle.css" type="text/css" rel="stylesheet"/>
            <link href="/css/diary.css" type="text/css" rel="stylesheet"/>
        @show
        @section('jquery')
            <script src="/js/jquery.js"></script>
        @show

    </head>
    <body>
            <div class="container">
                @yield('row1')
                @yield('row2')
            </div>
            <div class="footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4"></div>
                        <div class="col-md-4 main">
                            <p>Design by Whyte 2018&copy;</p>
                        </div>
                        <div class="col-md-4"></div>
                    </div>
                </div>
            </div>
            
    </body>
</html>