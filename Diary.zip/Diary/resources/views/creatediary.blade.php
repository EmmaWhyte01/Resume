@extends ('layout.diaryMaster')
@section ('title', 'Create Diary')
@section ('row1')
    <div class="row">
        <div class="col-md-6">
            <h1>MyDiary</h1>
        </div>
        <div class="col-md-4"></div>
        <div class="col-md-2">
        </div>
    </div>
@endsection
@section('row2')
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-6">
            <form role="form" method="post" action="{{ route('diary.create') }}">
                {{ csrf_field() }}
                @if( $status == 0 )
                    <div class="alert alert-danger">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    Already exist</div>
                @endif
                @foreach( $errors->all() as $error)
                    <div class="row alert alert-danger">
                        <ul>
                           <li>{{ $error }}</li>
                        </ul>
                    </div>
                @endforeach
                <div class="form-group">
                    <label for="email">What is on your mind:</label>
                    <textarea name="text" class="form-control" id="email"><?php if(isset($_REQUEST['text'])) echo $_REQUEST['text']; ?></textarea>
                </div>
                <div class="form-group">
                    <label for="pwd">How do feel:</label>
                    <select name="mood" class="form-control" id="pwd">
                        <option value="happy">Happy</option>
                        <option value="sad">Sad</option>
                        <option value="angry">Angry</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-info">Share</button>
            </form>
        </div>
        <div class="col-md-5"></div>
    </div>
@endsection