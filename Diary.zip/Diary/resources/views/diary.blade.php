@extends ('layout.diaryMaster')
@section ('title', 'My Diary')
@section ('row1')
    <div class="row">
        <div class="col-md-6">
            <h1>MyDiary</h1>
        </div>
        <div class="col-md-4"></div>
        <div class="col-md-2">
            <a href="{{ route('diary.write') }}" class="btn btn-info btn-sm">Share Something</a>
        </div>
    </div>
@endsection
@section ('row2')
    <div class="row">
                    <div class="col-md-12">
                        
                        <table class="table">
                            <tr>
                                <th>Entry</th>
                                <th>thougt</th>
                                <th>mood</th>
                                <th>action</th>
                            </tr>
                            @foreach($diarys as $diary)
                            <tr id="{{ $diary->id }}">
                                <td> {{ $diary->created_at }} </td>
                                <td class="hand">
                                    @if($diary->mark === 1)
                                        <p> {{ $diary->thougt }} </p>
                                    @else
                                        <p> {{ $diary->replace }} </p>
                                    @endif
                                </td>
                                <td>
                                    @if($diary->mood === 'happy')
                                        <img src="/images/ha.jpg" alt="i'm happy" />
                                    @elseif($diary->mood === 'sad')
                                        <img src="/images/sad.jpg" alt="i'm sad" />
                                    @else
                                        <img src="/images/angry.jpg" alt="i'm angry" />
                                    @endif
                                </td>
                                <td class="link">
                                    <a href=" {{ route('diary.delete', ['id' => $diary->id]) }} " class="btn btn-danger btn-anchor"><span class="glyphicon glyphicon-trash"></span>delete</a>
                                    @if($diary->mark === 1)
                                        <a href=" {{ route('diary.edit', ['id' => $diary->id]) }} " class="btn btn-info bn-sm"><span class="glyphicon glyphicon-pencil"></span>edit</a>
                                    @else
                                        <b class="text-muted v btn btn-default ">edit</b>
                                    @endif
                                    @if($diary->mark)
                                        <a href="{{ route('diary.mark', ['id' => $diary->id]) }}" class="btn btn-warning bn-sm"><span class="glyphicon glyphicon-mark"></span>hide</a>
                                    @else
                                        <a href="{{ route('diary.unmark', ['id' => $diary->id]) }}" class="btn btn-success bn-sm"><span class="glyphicon glyphicon-mark"></span>show</a>
                                    @endif
                                </td>
                            </tr>  
                            @endforeach
                        </table>
                        <div class="row text-center">
                            {{ $diarys->links() }}
                        </div>
                    </div>
                </div>
                <script src="/js/main.js"></script>
@endsection