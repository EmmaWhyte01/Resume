@extends ('layout.diaryMaster')
@section ('title', 'Update Diary')
@section ('row1')
    <div class="row">
        <div class="col-md-6">
            <h1>MyDiary</h1>
        </div>
        <div class="col-md-4"></div>
        <div class="col-md-2">
        </div>
    </div>
@endsection
@section('row2')
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-6">
            <form role="form" method="post" action="{{ route('diary.update', ['id'=>$up->id]) }}">
                {{ csrf_field() }}
                <div class="form-group">
                    <label for="email">What is on your mind:</label>
                    <textarea name="text" class="form-control" id="email"> {{ $up->thougt }} </textarea>
                </div>
                <div class="form-group">
                    <label for="pwd">How do feel:</label>
                    <select name="mood" class="form-control" id="pwd">
                        <option value="happy">Happy</option>
                        <option value="sad">Sad</option>
                        <option value="angry">Angry</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-info">Update</button>
            </form>
        </div>
        <div class="col-md-5"></div>
    </div>
@endsection