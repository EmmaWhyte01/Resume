<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\diaryModel;

class DiaryCon extends Controller
{
    public function index() {
        $list = diaryModel::paginate(7);
        return view('diary', ['diarys' => $list]);
    }

    public function write() {
        return view('creatediary', ['status' => '1']);
    }
    public function create() {
        request()->validate([
            'text' => 'bail|required|string|max:5000'
        ]);
        
        $check = DB::table('diary_models')->where([['thougt', '=', request()->text], ['mood', '=', request()->mood]])->count();
        //$check = diaryModel::all()->where([['thougt', '=', request()->text], ['mood', '=', request()->mood]])->count();
        
        //create new diaryModel object
        $myDiary = new diaryModel;
        

        if(! $check){
            
            //add item to diary
            $myDiary->thougt = request()->text;
            $myDiary->mood = request()->mood;

            //save item to database
            $myDiary->save();
            return redirect()->route('diary');
        }
        else{
            return view('creatediary', ['status' => '0']);
        }
        
    }

    public function edit($id) {
        return view('editdiary', ['up' => diaryModel::find($id)]);
    }
    public function delete($id) {
        $myDiary = diaryModel::find($id);

        $myDiary->delete();

        return redirect()->route('diary');
    }
    public function update($id) {
        $myDiary = diaryModel::find($id);
        $myDiary->thougt = request()->text;
        $myDiary->mood = request()->mood;
        $myDiary->save();
        return redirect()->route('diary');
    }
    public function unmark($id) {
        $myDiary = diaryModel::find($id);
        $myDiary->mark = 1;

        $myDiary->save();

        return redirect()->route('diary');
    }
    public function mark($id) {
        $myDiary = diaryModel::find($id);
        $myDiary->mark = 0;

        #$word = explode(' ', $myDiary->thougt);

        $replace = '*';
        $sum = str_repeat($replace, strlen($myDiary->thougt));
        $myDiary->replace = str_ireplace($myDiary->thougt, $myDiary->thougt, $sum);

        $myDiary->replace = chunk_split($myDiary->replace, 6);

        $myDiary->save();
        
        return redirect()->route('diary');
    }
}
