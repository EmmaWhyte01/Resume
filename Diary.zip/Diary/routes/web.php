<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [
    'uses' => 'DiaryCon@index',
    'as' =>'diary'
]);
Route::get('/diary/write', [
    'uses' => 'DiaryCon@write',
    'as' =>'diary.write'
]);
Route::post('/diary/create', [
    'uses' => 'DiaryCon@create',
    'as' =>'diary.create'
]);
Route::post('/diary/update/{id}', [
    'uses' => 'DiaryCon@update',
    'as' =>'diary.update'
]);
Route::get('/diary/delete/{id}', [
    'uses' => 'DiaryCon@delete',
    'as' =>'diary.delete'
]);
Route::get('/diary/edit/{id}', [
    'uses' => 'DiaryCon@edit',
    'as' =>'diary.edit'
]);
Route::get('/diary/mark/{id}', [
    'uses' => 'DiaryCon@mark',
    'as' =>'diary.mark'
]);
Route::get('/diary/unmark/{id}', [
    'uses' => 'DiaryCon@unmark',
    'as' =>'diary.unmark'
]);