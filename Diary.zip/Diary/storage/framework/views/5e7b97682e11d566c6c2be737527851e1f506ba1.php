<!DOCTYPE html>
<html lang="en">
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <?php $__env->startSection('meta-data'); ?>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php echo $__env->yieldSection(); ?>
        <?php $__env->startSection('core-css'); ?>
            <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
            <link href="/css/bootstrap.css" type="text/css" rel="stylesheet"/>
            <link href="/css/todostyle.css" type="text/css" rel="stylesheet"/>
            <link href="/css/diary.css" type="text/css" rel="stylesheet"/>
        <?php echo $__env->yieldSection(); ?>
        <?php $__env->startSection('jquery'); ?>
            <script src="/js/jquery.js"></script>
        <?php echo $__env->yieldSection(); ?>

    </head>
    <body>
            <div class="container">
                <?php echo $__env->yieldContent('row1'); ?>
                <?php echo $__env->yieldContent('row2'); ?>
            </div>
            <div class="footer">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4"></div>
                        <div class="col-md-4 main">
                            <p>Design by Whyte 2018&copy;</p>
                        </div>
                        <div class="col-md-4"></div>
                    </div>
                </div>
            </div>
            
    </body>
</html>