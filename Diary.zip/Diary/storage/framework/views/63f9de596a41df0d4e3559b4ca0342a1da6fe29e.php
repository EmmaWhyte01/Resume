<?php $__env->startSection('title', 'Create Diary'); ?>
<?php $__env->startSection('row1'); ?>
    <div class="row">
        <div class="col-md-6">
            <h1>MyDiary</h1>
        </div>
        <div class="col-md-4"></div>
        <div class="col-md-2">
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('row2'); ?>
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-6">
            <form role="form" method="post" action="<?php echo e(route('diary.create')); ?>">
                <?php echo e(csrf_field()); ?>

                <?php if( $status == 0 ): ?>
                    <div class="alert alert-danger">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    Already exist</div>
                <?php endif; ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row alert alert-danger">
                        <ul>
                           <li><?php echo e($error); ?></li>
                        </ul>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="form-group">
                    <label for="email">What is on your mind:</label>
                    <textarea name="text" class="form-control" id="email"><?php if(isset($_REQUEST['text'])) echo $_REQUEST['text']; ?></textarea>
                </div>
                <div class="form-group">
                    <label for="pwd">How do feel:</label>
                    <select name="mood" class="form-control" id="pwd">
                        <option value="happy">Happy</option>
                        <option value="sad">Sad</option>
                        <option value="angry">Angry</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-info">Share</button>
            </form>
        </div>
        <div class="col-md-5"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.diaryMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>