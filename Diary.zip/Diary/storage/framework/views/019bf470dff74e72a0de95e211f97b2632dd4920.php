<?php $__env->startSection('title', 'My Diary'); ?>
<?php $__env->startSection('row1'); ?>
    <div class="row">
        <div class="col-md-6">
            <h1>MyDiary</h1>
        </div>
        <div class="col-md-4"></div>
        <div class="col-md-2">
            <a href="<?php echo e(route('diary.write')); ?>" class="btn btn-info btn-sm">Share Something</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('row2'); ?>
    <div class="row">
                    <div class="col-md-12">
                        
                        <table class="table">
                            <tr>
                                <th>Entry</th>
                                <th>thougt</th>
                                <th>mood</th>
                                <th>action</th>
                            </tr>
                            <?php $__currentLoopData = $diarys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="<?php echo e($diary->id); ?>">
                                <td> <?php echo e($diary->created_at); ?> </td>
                                <td class="hand">
                                    <?php if($diary->mark === 1): ?>
                                        <p> <?php echo e($diary->thougt); ?> </p>
                                    <?php else: ?>
                                        <p> <?php echo e($diary->replace); ?> </p>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($diary->mood === 'happy'): ?>
                                        <img src="/images/ha.jpg" alt="i'm happy" />
                                    <?php elseif($diary->mood === 'sad'): ?>
                                        <img src="/images/sad.jpg" alt="i'm sad" />
                                    <?php else: ?>
                                        <img src="/images/angry.jpg" alt="i'm angry" />
                                    <?php endif; ?>
                                </td>
                                <td class="link">
                                    <a href=" <?php echo e(route('diary.delete', ['id' => $diary->id])); ?> " class="btn btn-danger btn-anchor"><span class="glyphicon glyphicon-trash"></span>delete</a>
                                    <?php if($diary->mark === 1): ?>
                                        <a href=" <?php echo e(route('diary.edit', ['id' => $diary->id])); ?> " class="btn btn-info bn-sm"><span class="glyphicon glyphicon-pencil"></span>edit</a>
                                    <?php else: ?>
                                        <b class="text-muted v btn btn-default ">edit</b>
                                    <?php endif; ?>
                                    <?php if($diary->mark): ?>
                                        <a href="<?php echo e(route('diary.mark', ['id' => $diary->id])); ?>" class="btn btn-warning bn-sm"><span class="glyphicon glyphicon-mark"></span>hide</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('diary.unmark', ['id' => $diary->id])); ?>" class="btn btn-success bn-sm"><span class="glyphicon glyphicon-mark"></span>show</a>
                                    <?php endif; ?>
                                </td>
                            </tr>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <div class="row text-center">
                            <?php echo e($diarys->links()); ?>

                        </div>
                    </div>
                </div>
                <script src="/js/main.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.diaryMaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>